# School App Project
This is a simple school app project.